// ResourceService.java
package com.example.evaluado3;

import com.tuempresa.recursosaprendizaje.model.Recurso;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.*;

public interface ResourceService {

    @GET("recursos")
    Call<List<Recurso>> getAllResources();

    @GET("recursos/{id}")
    Call<Recurso> getResourceById(@Path("id") int id);

    @POST("recursos")
    Call<Recurso> addResource(@Body Recurso recurso);

    @PUT("recursos/{id}")
    Call<Recurso> updateResource(@Path("id") int id, @Body Recurso recurso);

    @DELETE("recursos/{id}")
    Call<Void> deleteResource(@Path("id") int id);
}
