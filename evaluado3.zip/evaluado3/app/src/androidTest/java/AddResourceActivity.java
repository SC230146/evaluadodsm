// AddResourceActivity.java
package com.example.evaluado3;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.tuempresa.recursosaprendizaje.R;
import com.tuempresa.recursosaprendizaje.model.Recurso;
import com.tuempresa.recursosaprendizaje.network.RetrofitClient;
import com.tuempresa.recursosaprendizaje.network.ResourceService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddResourceActivity extends AppCompatActivity {

    private EditText editTitulo, editDescripcion, editTipo, editEnlace, editImagen;
    private Button btnAgregar;
    private ResourceService resourceService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_resource);

        editTitulo = findViewById(R.id.editTitulo);
        editDescripcion = findViewById(R.id.editDescripcion);
        editTipo = findViewById(R.id.editTipo);
        editEnlace = findViewById(R.id.editEnlace);
        editImagen = findViewById(R.id.editImagen);
        btnAgregar = findViewById(R.id.btnAgregar);

        resourceService = RetrofitClient.getClient().create(ResourceService.class);

        btnAgregar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                agregarRecurso();
            }
        });
    }

    private void agregarRecurso(){
        String titulo = editTitulo.getText().toString().trim();
        String descripcion = editDescripcion.getText().toString().trim();
        String tipo = editTipo.getText().toString().trim();
        String enlace = editEnlace.getText().toString().trim();
        String imagen = editImagen.getText().toString().trim();

        if(titulo.isEmpty() || descripcion.isEmpty() || tipo.isEmpty() || enlace.isEmpty() || imagen.isEmpty()){
            Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        // Crear un nuevo recurso. El ID puede ser asignado por el servidor.
        Recurso nuevoRecurso = new Recurso(0, titulo, descripcion, tipo, enlace, imagen);

        Call<Recurso> call = resourceService.addResource(nuevoRecurso);
        call.enqueue(new Callback<Recurso>() {
            @Override
            public void onResponse(Call<Recurso> call, Response<Recurso> response) {
                if(response.isSuccessful()){
                    Toast.makeText(AddResourceActivity.this, "Recurso agregado exitosamente", Toast.LENGTH_SHORT).show();
                    finish(); // Cerrar actividad y regresar
                } else {
                    Toast.makeText(AddResourceActivity.this, "Error al agregar recurso", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Recurso> call, Throwable t) {
                Toast.makeText(AddResourceActivity.this, "Fallo en la conexión", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
