// Constants.java
package com.example.evaluado3;

public class Constants {
    public static final String BASE_URL = "https://tuservidorapi.com/api/"; // Reemplaza con tu URL
}
