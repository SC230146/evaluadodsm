// ResourceActivity.java
package com.example.evaluado3;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.tuempresa.recursosaprendizaje.R;
import com.tuempresa.recursosaprendizaje.model.Recurso;
import com.tuempresa.recursosaprendizaje.network.RetrofitClient;
import com.tuempresa.recursosaprendizaje.network.ResourceService;
import com.tuempresa.recursosaprendizaje.ui.adapter.ResourceAdapter;
import com.tuempresa.recursosaprendizaje.ui.agregar.AddResourceActivity;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ResourceActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ResourceAdapter adapter;
    private List<Recurso> recursoList;
    private ResourceService resourceService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resource);

        recyclerView = findViewById(R.id.recyclerViewRecursos);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        recursoList = new ArrayList<>();
        adapter = new ResourceAdapter(recursoList, this);
        recyclerView.setAdapter(adapter);

        resourceService = RetrofitClient.getClient().create(ResourceService.class);

        fetchResources();
    }

    @Override
    protected void onResume() {
        super.onResume();
        fetchResources(); // Refrescar la lista al regresar a esta actividad
    }

    private void fetchResources() {
        Call<List<Recurso>> call = resourceService.getAllResources();
        call.enqueue(new Callback<List<Recurso>>() {
            @Override
            public void onResponse(Call<List<Recurso>> call, Response<List<Recurso>> response) {
                if(response.isSuccessful() && response.body() != null){
                    recursoList = response.body();
                    adapter.setRecursos(recursoList);
                } else {
                    Toast.makeText(ResourceActivity.this, "Error al obtener recursos", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Recurso>> call, Throwable t) {
                Toast.makeText(ResourceActivity.this, "Fallo en la conexión", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Inflar el menú para la búsqueda y agregar recurso
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);

        // Configurar SearchView
        MenuItem searchItem = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) searchItem.getActionView();

        searchView.setQueryHint("Buscar por ID...");

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query){
                if(!query.isEmpty()){
                    try {
                        int id = Integer.parseInt(query);
                        buscarRecursoPorId(id);
                    } catch (NumberFormatException e){
                        Toast.makeText(ResourceActivity.this, "Ingrese un ID válido", Toast.LENGTH_SHORT).show();
                    }
                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText){
                return false;
            }
        });

        return true;
    }

    private void buscarRecursoPorId(int id){
        Call<Recurso> call = resourceService.getResourceById(id);
        call.enqueue(new Callback<Recurso>() {
            @Override
            public void onResponse(Call<Recurso> call, Response<Recurso> response) {
                if(response.isSuccessful() && response.body() != null){
                    Recurso recurso = response.body();
                    // Mostrar un diálogo con la información del recurso
                    new android.app.AlertDialog.Builder(ResourceActivity.this)
                            .setTitle(recurso.getTitulo())
                            .setMessage(recurso.getDescripcion())
                            .setPositiveButton("Abrir Enlace", (dialog, which) -> {
                                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(recurso.getEnlace()));
                                startActivity(intent);
                            })
                            .setNegativeButton("Cerrar", null)
                            .show();
                } else {
                    Toast.makeText(ResourceActivity.this, "Recurso no encontrado", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Recurso> call, Throwable t) {
                Toast.makeText(ResourceActivity.this, "Fallo en la conexión", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Manejar selección de menú
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        if(item.getItemId() == R.id.action_add){
            // Navegar a AddResourceActivity
            Intent intent = new Intent(this, AddResourceActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
