// ResourceAdapter.java
package com.example.evaluado3;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.tuempresa.recursosaprendizaje.R;
import com.tuempresa.recursosaprendizaje.model.Recurso;
import com.tuempresa.recursosaprendizaje.network.RetrofitClient;
import com.tuempresa.recursosaprendizaje.network.ResourceService;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ResourceAdapter extends RecyclerView.Adapter<ResourceAdapter.ViewHolder> {

    private List<Recurso> recursos;
    private Context context;
    private ResourceService resourceService;

    public ResourceAdapter(List<Recurso> recursos, Context context) {
        this.recursos = recursos;
        this.context = context;
        this.resourceService = RetrofitClient.getClient().create(ResourceService.class);
    }

    @Override
    public ResourceAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_recurso, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ResourceAdapter.ViewHolder holder, int position) {
        Recurso recurso = recursos.get(position);
        holder.titulo.setText(recurso.getTitulo());
        holder.descripcion.setText(recurso.getDescripcion());
        holder.tipo.setText(recurso.getTipo());

        // Cargar imagen usando Glide
        Glide.with(context)
                .load(recurso.getImagen())
                .placeholder(R.drawable.placeholder) // Imagen por defecto
                .into(holder.imagen);

        holder.itemView.setOnClickListener(v -> {
            // Abrir el enlace en el navegador
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(recurso.getEnlace()));
            context.startActivity(intent);
        });

        holder.itemView.setOnLongClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle("Eliminar Recurso")
                    .setMessage("¿Estás seguro de eliminar este recurso?")
                    .setPositiveButton("Sí", (dialog, which) -> {
                        eliminarRecurso(recurso.getId(), position);
                    })
                    .setNegativeButton("No", null)
                    .show();
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return recursos.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView titulo, descripcion, tipo;
        ImageView imagen;

        public ViewHolder(View itemView) {
            super(itemView);
            titulo = itemView.findViewById(R.id.textTitulo);
            descripcion = itemView.findViewById(R.id.textDescripcion);
            tipo = itemView.findViewById(R.id.textTipo);
            imagen = itemView.findViewById(R.id.imageRecurso);
        }
    }

    // Métodos para actualizar la lista
    public void setRecursos(List<Recurso> recursos) {
        this.recursos = recursos;
        notifyDataSetChanged();
    }

    private void eliminarRecurso(int id, int position){
        Call<Void> call = resourceService.deleteResource(id);
        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if(response.isSuccessful()){
                    Toast.makeText(context, "Recurso eliminado", Toast.LENGTH_SHORT).show();
                    // Actualizar la lista
                    recursos.remove(position);
                    notifyItemRemoved(position);
                } else {
                    Toast.makeText(context, "Error al eliminar recurso", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(context, "Fallo en la conexión", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
