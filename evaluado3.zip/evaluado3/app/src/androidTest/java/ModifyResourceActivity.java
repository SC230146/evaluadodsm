// ModifyResourceActivity.java
package com.example.evaluado3.;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.tuempresa.recursosaprendizaje.R;
import com.tuempresa.recursosaprendizaje.model.Recurso;
import com.tuempresa.recursosaprendizaje.network.RetrofitClient;
import com.tuempresa.recursosaprendizaje.network.ResourceService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ModifyResourceActivity extends AppCompatActivity {

    private EditText editId, editTitulo, editDescripcion, editTipo, editEnlace, editImagen;
    private Button btnModificar;
    private ResourceService resourceService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_resource);

        editId = findViewById(R.id.editId);
        editTitulo = findViewById(R.id.editTitulo);
        editDescripcion = findViewById(R.id.editDescripcion);
        editTipo = findViewById(R.id.editTipo);
        editEnlace = findViewById(R.id.editEnlace);
        editImagen = findViewById(R.id.editImagen);
        btnModificar = findViewById(R.id.btnModificar);

        resourceService = RetrofitClient.getClient().create(ResourceService.class);

        btnModificar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                modificarRecurso();
            }
        });
    }

    private void modificarRecurso(){
        String idStr = editId.getText().toString().trim();
        if(idStr.isEmpty()){
            Toast.makeText(this, "Por favor, ingresa el ID del recurso", Toast.LENGTH_SHORT).show();
            return;
        }

        int id;
        try {
            id = Integer.parseInt(idStr);
        } catch (NumberFormatException e){
            Toast.makeText(this, "ID inválido", Toast.LENGTH_SHORT).show();
            return;
        }

        String titulo = editTitulo.getText().toString().trim();
        String descripcion = editDescripcion.getText().toString().trim();
        String tipo = editTipo.getText().toString().trim();
        String enlace = editEnlace.getText().toString().trim();
        String imagen = editImagen.getText().toString().trim();

        if(titulo.isEmpty() || descripcion.isEmpty() || tipo.isEmpty() || enlace.isEmpty() || imagen.isEmpty()){
            Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        Recurso recursoModificado = new Recurso(id, titulo, descripcion, tipo, enlace, imagen);

        Call<Recurso> call = resourceService.updateResource(id, recursoModificado);
        call.enqueue(new Callback<Recurso>() {
            @Override
            public void onResponse(Call<Recurso> call, Response<Recurso> response) {
                if(response.isSuccessful()){
                    Toast.makeText(ModifyResourceActivity.this, "Recurso modificado exitosamente", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(ModifyResourceActivity.this, "Error al modificar recurso", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Recurso> call, Throwable t) {
                Toast.makeText(ModifyResourceActivity.this, "Fallo en la conexión", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
