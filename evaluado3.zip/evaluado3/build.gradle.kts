// build.gradle (Proyecto)
buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath "com.android.tools.build:gradle:8.1.1" // Usa la versión más reciente disponible
        // NOTE: No añadas aquí dependencias de aplicaciones.
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

task clean(type: Delete) {
    delete rootProject.buildDir
}
